#ifndef DLG_H
#define DLG_H

#define ID_MAIN                     100

#define DID_EDIT1                   101
#define DID_EDIT2                   102
#define DID_LIST                    103

#endif /* DLG_H */
