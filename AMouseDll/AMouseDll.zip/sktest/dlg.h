#define ID_MAIN                     100

#define DID_UNSET                   101
#define DID_VK                      102
#define DID_SC                      103
