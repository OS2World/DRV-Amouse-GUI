#include <os2.h>
#include <stdio.h>

#include <Log.h>

#include "AMouHwnd.h"
#include "AMouData.h"

int main (void)
    {
    BOOL  bRC;
    ULONG fl;
    ULONG ul;

    TraceInit ("$$test$$.dbg");

    printf ("CULMAXWND = %d => %d\n", CULMAXWND, CULMAXWND*sizeof(WINDOWDATA) + 2*sizeof(PULONG));

    bRC = addWindowHandle (1, 0);
    printf ("result = %s\n", (bRC ? "True" : "False"));

    removeWindowHandle (1);

    bRC = addWindowHandle (1, 0);
    printf ("result = %s\n", (bRC ? "True" : "False"));

    bRC = addWindowHandle (2, 0);
    printf ("result = %s\n", (bRC ? "True" : "False"));

    bRC = addWindowHandle (3, 0);
    printf ("result = %s\n", (bRC ? "True" : "False"));

    bRC = addWindowHandle (4, 0);
    printf ("result = %s\n", (bRC ? "True" : "False"));

    for (ul = 0; ul < 520; ul++)
        {
        bRC = addWindowHandle (ul, 0);
        if (!bRC)
            printf ("result <%d> = %s\n", ul, (bRC ? "True" : "False"));
        }

    bRC = findWindowHandle (100, &ul);
    printf ("search for Window Handle  100: %s\n", (bRC ? "True" : "False"));

    bRC = findWindowHandle (3000, &ul);
    printf ("search for Window Handle 3000: %s\n", (bRC ? "True" : "False"));

    bRC = findWindowHandle (9999, &ul);
    printf ("search for Window Handle 9999: %s\n", (bRC ? "True" : "False"));

    removeWindowHandle (1);
    for (ul = 100; ul < 520; ul++)
        removeWindowHandle (ul);

    bRC = findWindowHandle (1, &ul);
    printf ("search for Window Handle    1: %s\n", (bRC ? "True" : "False"));

    bRC = findWindowHandle (2, &ul);
    printf ("search for Window Handle    2: %s\n", (bRC ? "True" : "False"));

    bRC = findWindowHandle (3000, &ul);
    printf ("search for Window Handle 3000: %s\n", (bRC ? "True" : "False"));

    bRC = findWindowHandle (9999, &ul);
    printf ("search for Window Handle 9999: %s\n", (bRC ? "True" : "False"));

    return 0;
    }

