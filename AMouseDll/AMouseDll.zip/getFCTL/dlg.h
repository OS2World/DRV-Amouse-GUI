#define ID_MAIN                     100

#define DID_HWND                    110
#define DID_TEST                    111
#define DID_P1                      112
#define DID_P2                      113
#define DID_P3                      114
#define DID_P4                      115
