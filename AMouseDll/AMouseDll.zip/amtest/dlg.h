#define ID_MAIN                     100

#define DID_SEND                    101
#define DID_WM                      102
#define DID_MP1                     103
#define DID_MP2                     104
#define DID_RC                      105
#define DID_HWND                    107
#define DID_TOGGLE                  108
