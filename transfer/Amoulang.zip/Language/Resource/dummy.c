void dummy (void)
{}
